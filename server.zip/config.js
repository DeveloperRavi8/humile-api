module.exports = {
  //Port
  PORT: process.env.PORT || 5000,

  //Secret key for API
  SECRET_KEY: "s@N)U!@_1",

  //Gmail credentials for send email
  EMAIL: "santoshkumar11051999@gmail.com",
  PASSWORD: "gnhu mekf zrgd sbnw", // Please fill this

  //Secret key for jwt
  JWT_SECRET: "Sanjay1@",

  //baseURL
  //baseURL: "https://admin.mirchimasala.in/",
  baseURL: "http://localhost/",

  //Firebase server key for send notification through firebase
  SERVER_KEY: "YOUR_SERVER_KEY",
};
